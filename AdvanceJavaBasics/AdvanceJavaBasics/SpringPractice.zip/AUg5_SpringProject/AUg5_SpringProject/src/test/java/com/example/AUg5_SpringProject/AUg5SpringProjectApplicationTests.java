package com.example.AUg5_SpringProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AUg5SpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
