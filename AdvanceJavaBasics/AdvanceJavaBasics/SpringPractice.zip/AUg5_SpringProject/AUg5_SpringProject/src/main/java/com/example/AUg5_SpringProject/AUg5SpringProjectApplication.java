package com.example.AUg5_SpringProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AUg5SpringProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(AUg5SpringProjectApplication.class, args);
	}

}
