package com.example.AUg5_SpringProject.Exception;

public class InvalidDataException extends RuntimeException{
    public InvalidDataException(){
        super();
    }
}
